| experiment | chunk_size | overlap | top_k | num_chunks | precision_at_k | recall_at_k | mrr | retrieval_abstain_rate | correctness | token_f1 | relevance | grounding | abstention_accuracy | false_abstain_rate | avg_latency_s |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| baseline | 900 | 150 | 4 | 25 | 0.000 | 0.000 | 0.000 | 1.000 | 0.000 | 0.000 | 0.000 | 0.000 | 1.000 | 1.000 | 2.009 |
| variant_a | 600 | 100 | 4 | 37 | 0.000 | 0.000 | 0.000 | 1.000 | 0.000 | 0.000 | 0.000 | 0.000 | 1.000 | 1.000 | 0.095 |
| variant_b | 900 | 150 | 6 | 25 | 0.000 | 0.000 | 0.000 | 1.000 | 0.000 | 0.000 | 0.000 | 0.000 | 1.000 | 1.000 | 0.085 |
| variant_c | 1200 | 200 | 4 | 19 | 0.000 | 0.000 | 0.000 | 1.000 | 0.000 | 0.000 | 0.000 | 0.000 | 1.000 | 1.000 | 0.071 |