"""Evaluate retrieval and generation and compare the four experiments.

Examples:
    python evaluate.py                              # retrieval metrics only (fast, no LLM)
    python evaluate.py --with-generation            # + correctness / relevance / grounding
    python evaluate.py --experiments baseline variant_a --rebuild
"""
import argparse
import csv
import json
import logging
import re
import sys
import time
from collections import Counter
from datetime import datetime, timezone

import numpy as np

import config
import rag_pipeline as rp


# ------------------------------------------------------------------ metric functions
def norm(text: str) -> str:
    return re.sub(r"\s+", " ", text.lower()).strip()


def is_relevant(chunk_text: str, evidence) -> bool:
    """A chunk is relevant if it contains at least one evidence phrase."""
    t = norm(chunk_text)
    return any(norm(e) in t for e in evidence)


def precision_at_k(flags, k: int) -> float:
    return sum(flags[:k]) / k if k else 0.0


def evidence_recall_at_k(hits, evidence) -> float:
    """Fraction of evidence phrases that appear in the retrieved chunks."""
    if not evidence:
        return 0.0
    joined = norm(" ".join(h["text"] for h in hits))
    return sum(norm(e) in joined for e in evidence) / len(evidence)


def reciprocal_rank(flags) -> float:
    for i, f in enumerate(flags, start=1):
        if f:
            return 1.0 / i
    return 0.0


def _tokens(text: str):
    return re.findall(r"[a-z0-9]+", text.lower())


def token_f1(prediction: str, reference: str) -> float:
    p, r = Counter(_tokens(prediction)), Counter(_tokens(reference))
    overlap = sum((p & r).values())
    if overlap == 0:
        return 0.0
    precision, recall = overlap / sum(p.values()), overlap / sum(r.values())
    return 2 * precision * recall / (precision + recall)


def keyword_coverage(answer: str, keywords) -> float:
    if not keywords:
        return 0.0
    a = answer.lower()
    return sum(k.lower() in a for k in keywords) / len(keywords)


def answer_relevance(question: str, answer: str) -> float:
    """Cosine similarity between question and answer embeddings (vectors are normalised)."""
    if not answer.strip():
        return 0.0
    q, a = rp.embed_texts([question, answer])
    return float(np.dot(q, a))


def mean(values):
    values = [v for v in values if v is not None]
    return float(np.mean(values)) if values else float("nan")


# ------------------------------------------------------------------ one experiment
def ensure_index(name: str, settings: config.RAGSettings, rebuild: bool) -> None:
    index_dir = config.index_path(name)
    if not rebuild and (index_dir / "index.faiss").exists():
        try:
            _, _, info = rp.load_index(index_dir)
            same = (info["settings"]["chunk_size"] == settings.chunk_size
                    and info["settings"]["overlap"] == settings.overlap
                    and info["embedding_model"] == config.EMBEDDING_MODEL
                    and info.get("documents_fingerprint") == rp.documents_fingerprint())
            if same:
                return
        except rp.RAGError:
            pass
    print(f"  building index '{name}' ...")
    rp.build_index(settings, show_progress=False)


def evaluate_experiment(name, settings, dataset, with_generation):
    pipe = rp.RAGPipeline(settings)
    k = settings.top_k
    rows = []
    for item in dataset:
        evidence = item.get("evidence", [])
        answerable = bool(evidence)
        hits = pipe.retrieve(item["question"], k)
        row = {"id": item["id"], "question": item["question"], "answerable": answerable,
               "best_score": hits[0]["score"] if hits else 0.0,
               "retrieved": [f"{h['source']} p.{h['page']} ({h['score']:.2f})" for h in hits]}
        if answerable:
            flags = [is_relevant(h["text"], evidence) for h in hits]
            row.update(precision_at_k=precision_at_k(flags, k),
                       recall_at_k=evidence_recall_at_k(hits, evidence),
                       reciprocal_rank=reciprocal_rank(flags))
        else:
            row["retrieval_abstain"] = row["best_score"] < config.MIN_SCORE
        if with_generation:
            t0 = time.time()
            res = pipe.ask(item["question"])
            row["latency_s"] = round(time.time() - t0, 2)
            row.update(answered=res["answered"], reason=res["reason"],
                       generated=res["answer"] or res["raw_answer"], grounding_value=res["grounding"])
            if answerable:
                ans = res["answer"]
                row.update(correctness=keyword_coverage(ans, item.get("answer_keywords", [])),
                           token_f1=token_f1(ans, item["reference_answer"]),
                           relevance=answer_relevance(item["question"], ans) if res["answered"] else 0.0,
                           grounding=res["grounding"] if res["answered"] else 0.0)
            else:
                row["correct_abstention"] = not res["answered"]
        rows.append(row)

    ans_rows = [r for r in rows if r["answerable"]]
    un_rows = [r for r in rows if not r["answerable"]]
    summary = {"experiment": name, "chunk_size": settings.chunk_size, "overlap": settings.overlap, "top_k": k,
               "num_chunks": len(pipe.chunks),
               "precision_at_k": mean(r["precision_at_k"] for r in ans_rows),
               "recall_at_k": mean(r["recall_at_k"] for r in ans_rows),
               "mrr": mean(r["reciprocal_rank"] for r in ans_rows),
               "retrieval_abstain_rate": mean(float(r["retrieval_abstain"]) for r in un_rows)}
    if with_generation:
        summary.update(correctness=mean(r["correctness"] for r in ans_rows),
                       token_f1=mean(r["token_f1"] for r in ans_rows),
                       relevance=mean(r["relevance"] for r in ans_rows),
                       grounding=mean(r["grounding"] for r in ans_rows),
                       abstention_accuracy=mean(float(r["correct_abstention"]) for r in un_rows),
                       false_abstain_rate=mean(float(not r["answered"]) for r in ans_rows),
                       avg_latency_s=mean(r["latency_s"] for r in rows))
    return summary, rows


# ------------------------------------------------------------------ reporting
def to_markdown(summaries) -> str:
    cols = list(summaries[0].keys())
    lines = ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    for s in summaries:
        lines.append("| " + " | ".join(f"{s[c]:.3f}" if isinstance(s[c], float) else str(s[c]) for c in cols) + " |")
    return "\n".join(lines)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Evaluate the RAG system and compare experiments.")
    parser.add_argument("--experiments", nargs="+", default=list(config.EXPERIMENTS), choices=list(config.EXPERIMENTS))
    parser.add_argument("--dataset", default=str(config.EVAL_DATASET_PATH))
    parser.add_argument("--with-generation", action="store_true", help="also run the LLM (needs GPU or a light model)")
    parser.add_argument("--rebuild", action="store_true", help="force rebuilding the indexes")
    parser.add_argument("--llm-model", help="override the Hugging Face model id")
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.WARNING, format="%(levelname)s: %(message)s")
    if args.llm_model:
        config.LLM_MODEL = args.llm_model

    try:
        with open(args.dataset, encoding="utf-8") as f:
            dataset = json.load(f)
    except FileNotFoundError:
        print(f"[ERROR] Evaluation dataset not found: {args.dataset}")
        return 1

    config.RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    summaries = []
    try:
        for name in args.experiments:
            settings = config.EXPERIMENTS[name]
            print(f"Experiment {name}: chunk={settings.chunk_size} overlap={settings.overlap} top_k={settings.top_k}")
            rp.set_seed()                                   # same seed for every experiment
            ensure_index(name, settings, args.rebuild)
            summary, rows = evaluate_experiment(name, settings, dataset, args.with_generation)
            summaries.append(summary)
            with open(config.RESULTS_DIR / f"{name}_details.json", "w", encoding="utf-8") as f:
                json.dump(rows, f, ensure_ascii=False, indent=2)
    except rp.RAGError as exc:
        print(f"[ERROR] {exc}")
        return 2

    meta = {"seed": config.SEED, "embedding_model": config.EMBEDDING_MODEL,
            "llm_model": config.LLM_MODEL if args.with_generation else None,
            "decoding": "greedy (do_sample=False)", "min_score": config.MIN_SCORE,
            "grounding_min": config.GROUNDING_MIN, "num_questions": len(dataset),
            "timestamp_utc": datetime.now(timezone.utc).isoformat(timespec="seconds")}
    with open(config.RESULTS_DIR / "experiment_comparison.json", "w", encoding="utf-8") as f:
        json.dump({"meta": meta, "summaries": summaries}, f, indent=2)
    fieldnames = list(summaries[-1].keys())
    with open(config.RESULTS_DIR / "experiment_comparison.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(summaries)
    (config.RESULTS_DIR / "experiment_comparison.md").write_text(to_markdown(summaries), encoding="utf-8")
    print("\n" + to_markdown(summaries))
    print(f"\nSaved in {config.RESULTS_DIR}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
