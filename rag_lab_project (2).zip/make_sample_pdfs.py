"""Create sample PDFs (using PyMuPDF itself) for testing the RAG system."""
import config

try:
    import pymupdf as fitz
except ImportError:
    import fitz

DOCS = {
    "rag_introduction.pdf": [
        ("Introduction to Retrieval-Augmented Generation",
         "Retrieval-Augmented Generation (RAG) is a technique that combines an information retrieval component "
         "with a generative language model. Instead of relying only on knowledge stored in the model parameters, "
         "a RAG system first searches an external document collection and then gives the retrieved passages to the "
         "language model as context. The concept was introduced by Lewis et al. in 2020. RAG is useful because "
         "language models have a fixed training cutoff, can hallucinate facts, and cannot access private documents. "
         "By grounding answers in retrieved text, a RAG system can reduce hallucinations and can cite the source of "
         "each statement. Updating the knowledge of a RAG system only requires re-indexing documents, while updating "
         "a pure language model requires expensive retraining or fine tuning."),
        ("The RAG Pipeline",
         "A RAG system has two phases: an offline indexing phase and an online query phase. During indexing, the "
         "system loads PDF files, extracts text with a library such as PyMuPDF, cleans the text, splits it into "
         "chunks, converts every chunk into an embedding vector with a Sentence Transformers model, and stores the "
         "vectors in a FAISS index together with metadata such as the file name and page number. During the query "
         "phase, the user question is converted into an embedding with the same model, the index returns the top k "
         "most similar chunks, these chunks are assembled into a prompt, and the language model generates an answer "
         "that should only use the retrieved context. Using the same embedding model for documents and queries is "
         "essential, because vectors from different models live in different spaces and cannot be compared."),
        ("Chunking Strategies",
         "Chunking splits long documents into smaller passages. The chunk size is the maximum number of characters "
         "in a chunk, and the overlap is the number of characters shared by two consecutive chunks. Small chunks are "
         "precise but may lose context needed to answer a question. Large chunks keep more context but contain more "
         "irrelevant text, which can dilute the embedding and waste the limited context window of the language model. "
         "Overlap prevents a sentence or fact from being cut in half at a chunk boundary. A common starting point is "
         "a chunk size of 900 characters with an overlap of 150 characters. Storing the page number with every chunk "
         "allows the system to show the exact source of an answer."),
    ],
    "vector_search_faiss.pdf": [
        ("Embeddings and Semantic Search",
         "An embedding is a dense numeric vector that represents the meaning of a piece of text. Sentence "
         "Transformers models such as all-MiniLM-L6-v2 map sentences and paragraphs to vectors with 384 dimensions. "
         "Texts with similar meaning are placed close together in the vector space, so semantic search can find "
         "relevant passages even when the question and the passage do not share the same words. Closeness is "
         "usually measured with cosine similarity. When all vectors are normalized to unit length, cosine "
         "similarity is equal to the inner product, which is why many systems normalize embeddings and use an inner "
         "product index."),
        ("FAISS: Efficient Similarity Search",
         "FAISS is a library developed by Facebook AI Research for efficient similarity search and clustering of "
         "dense vectors. The simplest index is IndexFlatL2, which performs exact brute force search using Euclidean "
         "distance. IndexFlatIP performs exact search using the inner product. Exact indexes are accurate and need "
         "no training, and they are appropriate for collections with up to several hundred thousand vectors. For "
         "much larger collections, approximate indexes such as IVF, which partitions the vectors into clusters, or "
         "HNSW, which builds a navigable graph, trade a small loss in accuracy for much faster search. A FAISS "
         "index can be saved to disk with write_index and loaded again with read_index. FAISS stores only vectors, "
         "so the text and metadata of each chunk must be saved separately, for example in a JSON file."),
    ],
    "llm_grounding_evaluation.pdf": [
        ("Hallucination and Grounding",
         "A hallucination is a fluent answer that is not supported by facts or by the provided context. RAG systems "
         "reduce hallucinations but do not remove them, because the model may ignore the context or mix it with its "
         "own memory. Good practice is to instruct the model to answer only from the context, to tell it to say "
         "that the answer is not available when the context is insufficient, to use greedy decoding with a low "
         "temperature for stable answers, and to show the sources to the user. Grounding measures whether the "
         "statements in an answer are supported by the retrieved passages. A retrieval confidence threshold can "
         "also be used: when the best similarity score is too low, the system should refuse to answer instead of "
         "guessing."),
        ("Evaluating a RAG System",
         "Retrieval and generation are evaluated separately. Precision at K is the fraction of the K retrieved "
         "chunks that are relevant. Recall at K is the fraction of the relevant evidence that appears among the K "
         "retrieved chunks. Mean Reciprocal Rank, or MRR, is the average over all questions of one divided by the "
         "rank of the first relevant chunk. For generation, answer correctness compares the generated answer with a "
         "reference answer, relevance checks that the answer addresses the question, and grounding checks that the "
         "answer is supported by the context. Experiments should change one parameter at a time, for example chunk "
         "size, overlap or the number of retrieved chunks, and should use a fixed random seed so that results can "
         "be reproduced."),
        ("Hardware Considerations",
         "Qwen2.5-3B-Instruct is an instruction tuned language model with about three billion parameters. In 16 bit "
         "precision it needs roughly 6 to 7 GB of memory, so it runs comfortably on a free Colab T4 GPU with 15 GB "
         "of memory. On a CPU the model is much slower, and a smaller model such as Qwen2.5-1.5B-Instruct is "
         "recommended. Scanned PDFs contain images of pages instead of text, so PyMuPDF returns no text; OCR tools "
         "such as Tesseract or OCRmyPDF must be used first."),
    ],
}


def write_pdf(path, pages):
    doc = fitz.open()
    for title, body in pages:
        page = doc.new_page()
        page.insert_textbox(fitz.Rect(54, 54, 541, 92), title, fontsize=16, fontname="hebo")
        leftover = page.insert_textbox(fitz.Rect(54, 100, 541, 788), body, fontsize=11, fontname="helv")
        if leftover < 0:
            raise RuntimeError(f"Text does not fit on a page of {path.name}")
    doc.save(str(path))
    doc.close()


def main():
    config.DOCUMENTS_DIR.mkdir(parents=True, exist_ok=True)
    for name, pages in DOCS.items():
        write_pdf(config.DOCUMENTS_DIR / name, pages)
        print("created", name, f"({len(pages)} pages)")
    blank = fitz.open()
    blank.new_page()
    blank.save(str(config.DOCUMENTS_DIR / "blank_scan_example.pdf"))
    blank.close()
    print("created blank_scan_example.pdf (1 empty page: tests empty/scanned PDF handling)")


if __name__ == "__main__":
    main()
