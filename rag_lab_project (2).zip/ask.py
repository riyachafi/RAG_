"""Ask questions about the indexed PDFs.

Examples:
    python ask.py --question "What is chunk overlap used for?"
    python ask.py                                  # interactive mode, type 'exit' to quit
    python ask.py --retrieval-only --question "What is FAISS?"
    python ask.py --experiment variant_b --llm-model Qwen/Qwen2.5-1.5B-Instruct
"""
import argparse
import logging
import sys

import config
import rag_pipeline as rp


def format_answer(res: dict) -> str:
    """Human-readable answer with sources (filename + page)."""
    lines = ["", f"Question: {res['question']}", "-" * 72]
    if res["answered"]:
        lines.append(f"Answer: {res['answer']}")
        lines.append(f"(grounding score: {res['grounding']:.2f})")
    else:
        lines.append(f"Answer: {config.NOT_FOUND_MESSAGE}")
        lines.append(f"(reason: {res['reason']}; best similarity: {res['best_score']:.3f}, "
                     f"threshold: {config.MIN_SCORE})")
    if res["sources"]:
        label = "Sources used" if res["answered"] else "Closest passages (not sufficient to answer)"
        lines.append(f"\n{label}:")
        for s in res["sources"]:
            lines.append(f"  [{s['rank']}] {s['source']} - page {s['page']}  (similarity {s['score']:.3f})")
    return "\n".join(lines)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Question answering over your PDFs (RAG).")
    parser.add_argument("--experiment", default="baseline", choices=list(config.EXPERIMENTS))
    parser.add_argument("--question", "-q", help="single question; omit for interactive mode")
    parser.add_argument("--top-k", type=int)
    parser.add_argument("--llm-model", help="override the Hugging Face model id")
    parser.add_argument("--retrieval-only", action="store_true", help="show passages, do not call the LLM")
    parser.add_argument("--show-context", action="store_true", help="print the retrieved text")
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.WARNING, format="%(levelname)s: %(message)s")
    rp.set_seed()

    try:
        pipe = rp.RAGPipeline(config.EXPERIMENTS[args.experiment], llm_model=args.llm_model)
    except rp.RAGError as exc:
        print(f"[ERROR] {exc}")
        return 1

    def handle(question: str) -> None:
        if args.retrieval_only:
            for h in pipe.retrieve(question, args.top_k):
                print(f"[{h['rank']}] {h['source']} p.{h['page']} (similarity {h['score']:.3f})\n    {h['text'][:300]}...")
            return
        res = pipe.ask(question, args.top_k)
        print(format_answer(res))
        if args.show_context and res["context"]:
            print("\n--- context given to the model ---\n" + res["context"])

    try:
        if args.question:
            handle(args.question)
            return 0
        print("RAG question answering. Type your question, or 'exit' to quit.")
        while True:
            try:
                q = input("\n> ").strip()
            except EOFError:
                break
            if q.lower() in {"exit", "quit", "q"}:
                break
            if q:
                handle(q)
        return 0
    except rp.ModelLoadError as exc:
        print(f"[ERROR] {exc}\nTip: try --llm-model {config.LIGHT_LLM_MODELS[0]} or --retrieval-only")
        return 2
    except rp.RAGError as exc:
        print(f"[ERROR] {exc}")
        return 2
    except KeyboardInterrupt:
        print("\nInterrupted.")
        return 0


if __name__ == "__main__":
    sys.exit(main())
