"""Central configuration for the RAG lab project."""
import os
from dataclasses import dataclass
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DOCUMENTS_DIR = BASE_DIR / "data" / "documents"
INDEX_DIR = BASE_DIR / "data" / "index"
RESULTS_DIR = BASE_DIR / "results"
EVAL_DATASET_PATH = BASE_DIR / "data" / "eval_dataset.json"

# ---- Models (override with environment variables) -------------------------------------------
EMBEDDING_MODEL = os.getenv("RAG_EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
LLM_MODEL = os.getenv("RAG_LLM_MODEL", "Qwen/Qwen2.5-3B-Instruct")
LIGHT_LLM_MODELS = ["Qwen/Qwen2.5-1.5B-Instruct", "Qwen/Qwen2.5-0.5B-Instruct"]

# ---- Reproducibility and generation ------------------------------------------------------------
SEED = 42
MAX_NEW_TOKENS = 256
EMBED_BATCH_SIZE = 32            # lower (e.g. 8) if you run out of memory
MAX_CONTEXT_CHARS = 6000         # hard cap on the context given to the LLM

# ---- Reliability thresholds -------------------------------------------------------------------
MIN_SCORE = float(os.getenv("RAG_MIN_SCORE", "0.25"))        # cosine similarity gate before generation
GROUNDING_MIN = float(os.getenv("RAG_GROUNDING_MIN", "0.30"))  # post-generation support check
MIN_CHARS_PER_PAGE = 20          # pages with fewer characters are treated as empty / scanned

NOT_FOUND_TOKEN = "NOT_FOUND"
NOT_FOUND_MESSAGE = "The answer is not available in the provided documents."


@dataclass(frozen=True)
class RAGSettings:
    """Parameters that define one RAG configuration (one experiment)."""
    name: str
    chunk_size: int   # maximum characters per chunk
    overlap: int      # characters shared by consecutive chunks
    top_k: int        # number of chunks retrieved per question


EXPERIMENTS = {
    "baseline":  RAGSettings("baseline", 900, 150, 4),
    "variant_a": RAGSettings("variant_a", 600, 100, 4),
    "variant_b": RAGSettings("variant_b", 900, 150, 6),
    "variant_c": RAGSettings("variant_c", 1200, 200, 4),
}


def index_path(name: str) -> Path:
    """Folder where the index of experiment `name` is stored."""
    return INDEX_DIR / name
