"""Build and save the FAISS index for one RAG configuration.

Examples:
    python build_index.py                          # baseline (900 / 150 / 4)
    python build_index.py --experiment variant_a
    python build_index.py --chunk-size 700 --overlap 100 --name my_run
"""
import argparse
import dataclasses
import logging
import sys

import config
import rag_pipeline as rp


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Build the FAISS index from the PDFs in data/documents.")
    parser.add_argument("--experiment", default="baseline", choices=list(config.EXPERIMENTS))
    parser.add_argument("--chunk-size", type=int, help="override chunk size (characters)")
    parser.add_argument("--overlap", type=int, help="override overlap (characters)")
    parser.add_argument("--top-k", type=int, help="override top_k stored with the index")
    parser.add_argument("--name", help="custom name -> data/index/<name>")
    parser.add_argument("--documents-dir", default=str(config.DOCUMENTS_DIR))
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    settings = config.EXPERIMENTS[args.experiment]
    overrides = {k: v for k, v in {"chunk_size": args.chunk_size, "overlap": args.overlap,
                                   "top_k": args.top_k, "name": args.name}.items() if v is not None}
    settings = dataclasses.replace(settings, **overrides)
    print(f"Building index '{settings.name}': chunk_size={settings.chunk_size}, "
          f"overlap={settings.overlap}, top_k={settings.top_k}")
    try:
        info = rp.build_index(settings, documents_dir=args.documents_dir)
    except FileNotFoundError as exc:
        print(f"[ERROR] {exc}")
        return 1
    except rp.RAGError as exc:
        print(f"[ERROR] {exc}")
        return 2

    print("\nDocument report:")
    for doc in info["documents"]:
        status = f"ERROR: {doc['error']}" if doc["error"] else f"{doc['pages_with_text']}/{doc['pages_total']} pages with text"
        print(f"  - {doc['file']}: {status}")
        for w in doc["warnings"]:
            print(f"      [warning] {w}")
    print(f"\nDone: {info['num_chunks']} chunks from {info['num_pages']} pages "
          f"(embedding dim {info['embedding_dim']}).")
    print(f"Index saved in: {config.index_path(settings.name)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
