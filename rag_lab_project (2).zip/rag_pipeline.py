"""Core RAG pipeline: PDF loading, cleaning, chunking, embedding, FAISS, retrieval, generation."""
from __future__ import annotations

import hashlib
import json
import logging
import os
import random
import re
import unicodedata
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np

import config
from config import RAGSettings

os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
logger = logging.getLogger("rag")

try:                      # PyMuPDF >= 1.24 exposes `pymupdf`; older versions expose `fitz`
    import pymupdf as fitz
except ImportError:       # pragma: no cover
    import fitz


# ====================================================================== exceptions
class RAGError(Exception):
    """Base class of all expected, user-explainable errors."""


class PDFLoadError(RAGError):
    pass


class NoTextError(RAGError):
    pass


class IndexNotFoundError(RAGError):
    pass


class ModelLoadError(RAGError):
    pass


# ====================================================================== utilities
def set_seed(seed: int = config.SEED) -> None:
    """Seed every random number generator we use (reproducible experiments)."""
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except ImportError:
        pass


def _device() -> str:
    try:
        import torch
        return "cuda" if torch.cuda.is_available() else "cpu"
    except ImportError:
        return "cpu"


# ====================================================================== stage 3: cleaning
_CONTROL_CHARS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def clean_text(text: str) -> str:
    """Normalise raw PDF text so that it embeds well."""
    if not text:
        return ""
    text = unicodedata.normalize("NFKC", text)           # ligatures, full-width chars, nbsp ...
    text = text.replace("\u00ad", "")                    # soft hyphen
    text = _CONTROL_CHARS.sub(" ", text)
    text = re.sub(r"(\w)-[ \t]*[\r\n]+[ \t]*(\w)", r"\1\2", text)   # re-join "retriev-\nal"
    text = re.sub(r"\s*[\r\n]+\s*", " ", text)           # line breaks -> space
    text = re.sub(r"[ \t\u00a0]+", " ", text)
    return text.strip()


# ====================================================================== stages 1-2: loading
def load_pdf_pages(pdf_path) -> Tuple[List[dict], int, List[str]]:
    """Extract cleaned text page by page. Returns (pages, total_pages, warnings)."""
    pdf_path = Path(pdf_path)
    pages: List[dict] = []
    warnings: List[str] = []
    try:
        doc = fitz.open(str(pdf_path))
    except Exception as exc:
        raise PDFLoadError(f"Cannot open '{pdf_path.name}': {exc}") from exc
    with doc:
        if getattr(doc, "needs_pass", False):
            raise PDFLoadError(f"'{pdf_path.name}' is password protected.")
        total = doc.page_count
        if total == 0:
            warnings.append(f"{pdf_path.name}: the PDF has no pages (empty file).")
        for number, page in enumerate(doc, start=1):
            text = clean_text(page.get_text("text"))
            if len(text) < config.MIN_CHARS_PER_PAGE:
                if page.get_images():
                    warnings.append(f"{pdf_path.name} p.{number}: no text but contains images -> probably a "
                                    f"SCANNED page. Run OCR first (OCRmyPDF / Tesseract).")
                else:
                    warnings.append(f"{pdf_path.name} p.{number}: empty page skipped.")
                continue
            pages.append({"source": pdf_path.name, "page": number, "text": text})
    return pages, total, warnings


def load_documents(documents_dir=config.DOCUMENTS_DIR) -> Tuple[List[dict], List[dict]]:
    """Load every PDF in a folder. Returns (pages, per-file report)."""
    documents_dir = Path(documents_dir)
    if not documents_dir.is_dir():
        raise FileNotFoundError(f"Documents folder not found: {documents_dir}. Create it and add PDF files.")
    pdf_files = sorted(p for p in documents_dir.iterdir() if p.suffix.lower() == ".pdf")
    if not pdf_files:
        raise FileNotFoundError(f"No PDF files found in {documents_dir}. Copy your PDFs there.")
    all_pages: List[dict] = []
    report: List[dict] = []
    for pdf in pdf_files:
        try:
            pages, total, warnings = load_pdf_pages(pdf)
            report.append({"file": pdf.name, "pages_total": total, "pages_with_text": len(pages),
                           "warnings": warnings, "error": None})
            all_pages.extend(pages)
        except PDFLoadError as exc:
            report.append({"file": pdf.name, "pages_total": 0, "pages_with_text": 0,
                           "warnings": [], "error": str(exc)})
    if not all_pages:
        raise NoTextError(
            "No text could be extracted from any PDF. The files are empty, corrupted or SCANNED images. "
            "PyMuPDF does not perform OCR: convert scans with OCRmyPDF ('ocrmypdf in.pdf out.pdf') or "
            "Tesseract, then put the searchable PDFs in the documents folder.")
    return all_pages, report


def documents_fingerprint(documents_dir=config.DOCUMENTS_DIR) -> str:
    """Hash of file names and sizes; lets us detect that the PDFs changed since the index was built."""
    h = hashlib.sha1()
    for p in sorted(Path(documents_dir).glob("*.pdf")):
        h.update(f"{p.name}:{p.stat().st_size}".encode())
    return h.hexdigest()


# ====================================================================== stage 4: chunking
def split_text(text: str, chunk_size: int, overlap: int) -> List[str]:
    """Split text into windows of at most `chunk_size` characters sharing `overlap` characters."""
    if chunk_size <= 0:
        raise ValueError("chunk_size must be positive.")
    if overlap < 0 or overlap >= chunk_size:
        raise ValueError("overlap must satisfy 0 <= overlap < chunk_size.")
    text = text.strip()
    if not text:
        return []
    if len(text) <= chunk_size:
        return [text]
    chunks: List[str] = []
    n, start = len(text), 0
    while start < n:
        end = min(start + chunk_size, n)
        if end < n:                                   # avoid cutting a word: back up to the last space
            cut = text.rfind(" ", start + int(chunk_size * 0.8), end)
            if cut != -1:
                end = cut
        piece = text[start:end].strip()
        if len(piece) >= 20 or not chunks:
            chunks.append(piece)
        if end >= n:
            break
        next_start = end - overlap
        if next_start <= start:                       # safety: always move forward
            next_start = end
        space = text.find(" ", next_start, end)       # start the next chunk at a word boundary
        if space != -1:
            next_start = space + 1
        start = next_start
    return chunks


def chunk_pages(pages: List[dict], chunk_size: int, overlap: int) -> List[dict]:
    """Chunk each page separately so that every chunk has an exact (source, page)."""
    chunks: List[dict] = []
    for p in pages:
        for j, piece in enumerate(split_text(p["text"], chunk_size, overlap)):
            chunks.append({"chunk_id": len(chunks), "source": p["source"], "page": p["page"],
                           "chunk_in_page": j, "text": piece})
    return chunks


# ====================================================================== stage 5: embeddings
_EMBEDDERS: Dict[str, object] = {}


def get_embedder(model_name: Optional[str] = None):
    """Load (once) and return the Sentence-Transformers model."""
    model_name = model_name or config.EMBEDDING_MODEL
    if model_name not in _EMBEDDERS:
        try:
            from sentence_transformers import SentenceTransformer
            _EMBEDDERS[model_name] = SentenceTransformer(model_name, device=_device())
        except Exception as exc:
            raise ModelLoadError(
                f"Could not load embedding model '{model_name}': {exc}\n"
                "Check your internet connection (first download) and the model name.") from exc
    return _EMBEDDERS[model_name]


def embed_texts(texts: List[str], model_name: Optional[str] = None,
                batch_size: int = config.EMBED_BATCH_SIZE, show_progress: bool = False) -> np.ndarray:
    """Return L2-normalised float32 embeddings, shape (len(texts), dim)."""
    model = get_embedder(model_name)
    emb = model.encode(texts, batch_size=batch_size, convert_to_numpy=True,
                       normalize_embeddings=True, show_progress_bar=show_progress)
    return np.ascontiguousarray(emb, dtype="float32")


# ====================================================================== stages 6-7: FAISS + persistence
def build_faiss_index(embeddings: np.ndarray):
    """Exact inner-product index (cosine similarity because vectors are normalised)."""
    import faiss
    index = faiss.IndexFlatIP(int(embeddings.shape[1]))
    index.add(embeddings)
    return index


def save_index(index, chunks: List[dict], info: dict, index_dir) -> None:
    import faiss
    index_dir = Path(index_dir)
    index_dir.mkdir(parents=True, exist_ok=True)
    faiss.write_index(index, str(index_dir / "index.faiss"))
    (index_dir / "chunks.json").write_text(json.dumps(chunks, ensure_ascii=False, indent=1), encoding="utf-8")
    (index_dir / "index_info.json").write_text(json.dumps(info, ensure_ascii=False, indent=2), encoding="utf-8")


def load_index(index_dir):
    """Return (faiss_index, chunks, info). Raises IndexNotFoundError if anything is missing."""
    import faiss
    index_dir = Path(index_dir)
    needed = ["index.faiss", "chunks.json", "index_info.json"]
    missing = [f for f in needed if not (index_dir / f).exists()]
    if missing:
        raise IndexNotFoundError(f"Index not found in '{index_dir}' (missing: {', '.join(missing)}). "
                                 f"Run 'python build_index.py' first.")
    try:
        index = faiss.read_index(str(index_dir / "index.faiss"))
        chunks = json.loads((index_dir / "chunks.json").read_text(encoding="utf-8"))
        info = json.loads((index_dir / "index_info.json").read_text(encoding="utf-8"))
    except Exception as exc:
        raise IndexNotFoundError(f"Index in '{index_dir}' is corrupted ({exc}). Rebuild it.") from exc
    if index.ntotal != len(chunks):
        raise IndexNotFoundError("Index and chunk metadata are out of sync. Rebuild the index.")
    return index, chunks, info


def build_index(settings: RAGSettings, documents_dir=config.DOCUMENTS_DIR, index_dir=None,
                embedding_model: Optional[str] = None, show_progress: bool = True) -> dict:
    """Stages 1-7: PDFs -> pages -> chunks -> embeddings -> FAISS -> disk."""
    embedding_model = embedding_model or config.EMBEDDING_MODEL
    index_dir = Path(index_dir) if index_dir else config.index_path(settings.name)
    set_seed()
    pages, report = load_documents(documents_dir)
    chunks = chunk_pages(pages, settings.chunk_size, settings.overlap)
    if not chunks:
        raise NoTextError("Text was extracted but produced no chunks.")
    embeddings = embed_texts([c["text"] for c in chunks], embedding_model, show_progress=show_progress)
    index = build_faiss_index(embeddings)
    info = {
        "settings": {"name": settings.name, "chunk_size": settings.chunk_size,
                     "overlap": settings.overlap, "top_k": settings.top_k},
        "embedding_model": embedding_model,
        "embedding_dim": int(embeddings.shape[1]),
        "num_chunks": len(chunks),
        "num_pages": len(pages),
        "documents": report,
        "documents_fingerprint": documents_fingerprint(documents_dir),
        "created_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    save_index(index, chunks, info, index_dir)
    return info


# ====================================================================== stages 8-9: retrieval + context
def retrieve(question: str, index, chunks: List[dict], top_k: int,
             embedding_model: Optional[str] = None) -> List[dict]:
    """Return the top_k most similar chunks with rank and cosine score."""
    q = embed_texts([question], embedding_model)
    k = max(1, min(top_k, index.ntotal))
    scores, ids = index.search(q, k)
    hits = []
    for rank, (score, idx) in enumerate(zip(scores[0], ids[0]), start=1):
        if idx < 0:
            continue
        hits.append({"rank": rank, "score": float(score), **chunks[int(idx)]})
    return hits


def build_context(hits: List[dict], max_chars: int = config.MAX_CONTEXT_CHARS) -> str:
    """Numbered passages with their source, truncated to `max_chars`."""
    parts, used = [], 0
    for h in hits:
        block = f"[{h['rank']}] (source: {h['source']}, page {h['page']})\n{h['text']}"
        if used + len(block) > max_chars and parts:
            break
        parts.append(block)
        used += len(block)
    return "\n\n".join(parts)


SYSTEM_PROMPT = (
    "You are a careful assistant that answers questions using ONLY the numbered context passages provided. "
    "Rules: (1) Use only facts stated in the context; never use outside knowledge. "
    "(2) If the context does not contain the answer, reply with exactly: " + config.NOT_FOUND_TOKEN + ". "
    "(3) Be concise (1-4 sentences) and cite the passages you used like [1] or [2]. "
    "(4) Answer in the language of the question."
)


def build_messages(question: str, context: str) -> List[dict]:
    return [{"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"Context:\n{context}\n\nQuestion: {question}\nAnswer:"}]


# ====================================================================== stage 10: generation
_LLMS: Dict[str, tuple] = {}


def get_llm(model_name: Optional[str] = None):
    """Load (once) tokenizer + causal LM. float16 on GPU, float32 on CPU."""
    model_name = model_name or config.LLM_MODEL
    if model_name in _LLMS:
        return _LLMS[model_name]
    try:
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
    except ImportError as exc:
        raise ModelLoadError(f"Missing dependency: {exc}. Run 'pip install -r requirements.txt'.") from exc
    device = _device()
    dtype = torch.float16 if device == "cuda" else torch.float32
    logger.info("Loading LLM %s on %s (%s) ...", model_name, device, dtype)
    try:
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        try:
            model = AutoModelForCausalLM.from_pretrained(model_name, dtype=dtype, low_cpu_mem_usage=True)
        except TypeError:                              # older transformers use torch_dtype
            model = AutoModelForCausalLM.from_pretrained(model_name, torch_dtype=dtype, low_cpu_mem_usage=True)
        model.to(device)
        model.eval()
    except (OSError, RuntimeError, ValueError, MemoryError) as exc:
        hint = ("Out of memory: use a lighter model, e.g. set RAG_LLM_MODEL=" + config.LIGHT_LLM_MODELS[0]
                if "memory" in str(exc).lower() else
                "Check the model name and your internet connection (first download is ~6 GB for the 3B model).")
        raise ModelLoadError(f"Could not load LLM '{model_name}': {exc}\n{hint}") from exc
    _LLMS[model_name] = (tokenizer, model)
    return _LLMS[model_name]


def generate_answer(messages: List[dict], model_name: Optional[str] = None,
                    max_new_tokens: int = config.MAX_NEW_TOKENS) -> str:
    """Greedy decoding (deterministic). Returns only the newly generated text."""
    import torch
    tokenizer, model = get_llm(model_name)
    prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    with torch.no_grad():
        output = model.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=False,
                                pad_token_id=tokenizer.eos_token_id)
    new_tokens = output[0][inputs["input_ids"].shape[1]:]
    return tokenizer.decode(new_tokens, skip_special_tokens=True).strip()


# ====================================================================== grounding check
_STOPWORDS = set("""the and for are was were that this with from have has had not but you your can will would could
should into than then them they their there these those what which who whom how why when where while also its it's
about over under such only may might must been being does did done each other any all one two use used using based
per via our out off too very more most less same""".split())


def _content_tokens(text: str) -> set:
    tokens = set()
    for t in re.findall(r"[a-z0-9]+", text.lower()):
        if t in _STOPWORDS or (len(t) <= 2 and not t.isdigit()):
            continue
        if len(t) > 3 and t.endswith("s"):
            t = t[:-1]
        tokens.add(t)
    return tokens


def grounding_score(answer: str, context: str, support_threshold: float = 0.6) -> float:
    """Fraction of answer sentences whose content words are (mostly) present in the context."""
    answer = re.sub(r"\[\d+\]", " ", answer or "")
    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+|\n+", answer) if s.strip()]
    ctx_tokens = _content_tokens(context)
    supported, total = 0, 0
    for s in sentences:
        toks = _content_tokens(s)
        if not toks:
            continue
        total += 1
        if len(toks & ctx_tokens) / len(toks) >= support_threshold:
            supported += 1
    return supported / total if total else 0.0


# ====================================================================== stage 11: full pipeline
class RAGPipeline:
    """Question answering over a stored FAISS index, with protection against unsupported answers."""

    def __init__(self, settings: RAGSettings, index_dir=None, embedding_model: Optional[str] = None,
                 llm_model: Optional[str] = None, min_score: Optional[float] = None,
                 grounding_min: Optional[float] = None):
        self.settings = settings
        self.index_dir = Path(index_dir) if index_dir else config.index_path(settings.name)
        self.embedding_model = embedding_model or config.EMBEDDING_MODEL
        self.llm_model = llm_model
        self.min_score = config.MIN_SCORE if min_score is None else min_score
        self.grounding_min = config.GROUNDING_MIN if grounding_min is None else grounding_min
        self.index, self.chunks, self.info = load_index(self.index_dir)
        if self.info.get("embedding_model") != self.embedding_model:
            raise RAGError(f"Index was built with '{self.info.get('embedding_model')}' but the current embedding "
                           f"model is '{self.embedding_model}'. Rebuild the index (build_index.py --rebuild).")

    def retrieve(self, question: str, top_k: Optional[int] = None) -> List[dict]:
        return retrieve(question, self.index, self.chunks, top_k or self.settings.top_k, self.embedding_model)

    def ask(self, question: str, top_k: Optional[int] = None) -> dict:
        question = (question or "").strip()
        result = {"question": question, "answer": "", "answered": False, "reason": "", "sources": [],
                  "context": "", "grounding": None, "best_score": 0.0, "raw_answer": ""}
        if not question:
            result["reason"] = "empty_question"
            return result
        hits = self.retrieve(question, top_k)
        result["sources"] = hits
        if not hits:
            result["reason"] = "no_results"
            return result
        result["best_score"] = hits[0]["score"]
        if result["best_score"] < self.min_score:             # gate 1: nothing similar enough
            result["reason"] = "low_retrieval_score"
            return result
        context = build_context(hits)
        result["context"] = context
        raw = generate_answer(build_messages(question, context), self.llm_model)
        result["raw_answer"] = raw
        if not raw.strip():
            result["reason"] = "empty_generation"
            return result
        if re.search(r"\b" + config.NOT_FOUND_TOKEN + r"\b", raw):   # gate 2: the model itself abstained
            result["reason"] = "model_not_found"
            return result
        grounding = grounding_score(raw, context)
        result["grounding"] = grounding
        if grounding < self.grounding_min:                    # gate 3: answer not supported by context
            result["reason"] = "low_grounding"
            return result
        result["answer"], result["answered"], result["reason"] = raw, True, "ok"
        return result
